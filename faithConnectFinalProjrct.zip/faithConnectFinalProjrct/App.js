alert ('Our web was not completed')
// Sample data (replace this with your actual data)
const verses = [
    {
        "book": "Genesis",
        "chapter": 1,
        "verse": 1,
        "text": "In the beginning God created the heaven and the earth."
    },
    {
        "book": "Exodus",
        "chapter": 20,
        "verse": 13,
        "text": "Thou shalt not kill."
    },
    {
        "book": "John",
        "chapter": 3,
        "verse": 16,
        "text": "For God so loved the world, that he gave his only begotten Son..."
    },
    {
        "book": "Leviticus",
        "chapter": 19,
        "verse": 18,
        "text": "Thou shalt love thy neighbour as thyself: I am the LORD."
    },
    {
        "book": "Numbers",
        "chapter": 6,
        "verse": 24,
        "text": "The LORD bless thee, and keep thee."
    },
    {
        "book": "Deuteronomy",
        "chapter": 6,
        "verse": 5,
        "text": "And thou shalt love the LORD thy God with all thine heart, and with all thy soul, and with all thy might."
    },
    {
        "book": "Joshua",
        "chapter": 1,
        "verse": 9,
        "text": "Be strong and of a good courage; be not afraid, neither be thou dismayed: for the LORD thy God is with thee whithersoever thou goest."
    },
    {
        "book": "Judges",
        "chapter": 6,
        "verse": 12,
        "text": "The LORD is with thee, thou mighty man of valour."
    },
    {
        "book": "Ruth",
        "chapter": 1,
        "verse": 16,
        "text": "For whither thou goest, I will go; and where thou lodgest, I will lodge: thy people shall be my people, and thy God my God."
    },
    {
        "book": "1 Samuel",
        "chapter": 17,
        "verse": 45,
        "text": "Thou comest to me with a sword, and with a spear, and with a shield: but I come to thee in the name of the LORD of hosts."
    },
    {
        "book": "2 Samuel",
        "chapter": 22,
        "verse": 2,
        "text": "The LORD is my rock, and my fortress, and my deliverer."
    },
    {
        "book": "1 Kings",
        "chapter": 8,
        "verse": 23,
        "text": "There is no God like thee, in heaven above, or on earth beneath."
    },
    {
        "book": "2 Kings",
        "chapter": 6,
        "verse": 16,
        "text": "Fear not: for they that be with us are more than they that be with them."
    },
    {
        "book": "1 Chronicles",
        "chapter": 16,
        "verse": 34,
        "text": "O give thanks unto the LORD; for he is good; for his mercy endureth for ever."
    },
    {
        "book": "2 Chronicles",
        "chapter": 7,
        "verse": 14,
        "text": "If my people, which are called by my name, shall humble themselves, and pray, and seek my face, and turn from their wicked ways; then will I hear from heaven."
    },
    {
        "book": "Ezra",
        "chapter": 7,
        "verse": 10,
        "text": "For Ezra had prepared his heart to seek the law of the LORD, and to do it."
    },
    {
        "book": "Nehemiah",
        "chapter": 8,
        "verse": 10,
        "text": "The joy of the LORD is your strength."
    },
    {
        "book": "Esther",
        "chapter": 4,
        "verse": 14,
        "text": "Who knoweth whether thou art come to the kingdom for such a time as this?"
    },
    {
        "book": "Job",
        "chapter": 1,
        "verse": 21,
        "text": "The LORD gave, and the LORD hath taken away; blessed be the name of the LORD."
    },
    {
        "book": "Psalms",
        "chapter": 23,
        "verse": 1,
        "text": "The LORD is my shepherd; I shall not want."
    },
    {
        "book": "Psalms",
        "chapter": 46,
        "verse": 1,
        "text": "God is our refuge and strength, a very present help in trouble."
    },
    {
        "book": "Psalms",
        "chapter": 119,
        "verse": 105,
        "text": "Thy word is a lamp unto my feet, and a light unto my path."
    },
    {
        "book": "Proverbs",
        "chapter": 3,
        "verse": 5,
        "text": "Trust in the LORD with all thine heart; and lean not unto thine own understanding."
    },
    {
        "book": "Proverbs",
        "chapter": 18,
        "verse": 10,
        "text": "The name of the LORD is a strong tower: the righteous runneth into it, and is safe."
    },
    {
        "book": "Ecclesiastes",
        "chapter": 3,
        "verse": 1,
        "text": "To every thing there is a season, and a time to every purpose under the heaven."
    },
    {
        "book": "Song of Solomon",
        "chapter": 2,
        "verse": 16,
        "text": "My beloved is mine, and I am his."
    },
    {
        "book": "Isaiah",
        "chapter": 40,
        "verse": 31,
        "text": "But they that wait upon the LORD shall renew their strength; they shall mount up with wings as eagles."
    },
    {
        "book": "Isaiah",
        "chapter": 41,
        "verse": 10,
        "text": "Fear thou not; for I am with thee: be not dismayed; for I am thy God."
    },
    {
        "book": "Jeremiah",
        "chapter": 29,
        "verse": 11,
        "text": "For I know the thoughts that I think toward you, saith the LORD, thoughts of peace, and not of evil, to give you an expected end."
    },
    {
        "book": "Lamentations",
        "chapter": 3,
        "verse": 22,
        "text": "It is of the LORD's mercies that we are not consumed, because his compassions fail not."
    },
    {
        "book": "Ezekiel",
        "chapter": 36,
        "verse": 26,
        "text": "A new heart also will I give you, and a new spirit will I put within you."
    },
    {
        "book": "Daniel",
        "chapter": 3,
        "verse": 18,
        "text": "But if not, be it known unto thee, O king, that we will not serve thy gods."
    },
    {
        "book": "Hosea",
        "chapter": 6,
        "verse": 6,
        "text": "For I desired mercy, and not sacrifice; and the knowledge of God more than burnt offerings."
    },
    {
        "book": "Joel",
        "chapter": 2,
        "verse": 28,
        "text": "And it shall come to pass afterward, that I will pour out my spirit upon all flesh."
    },
    {
        "book": "Amos",
        "chapter": 5,
        "verse": 24,
        "text": "But let judgment run down as waters, and righteousness as a mighty stream."
    },
    {
        "book": "Obadiah",
        "chapter": 1,
        "verse": 15,
        "text": "For the day of the LORD is near upon all the heathen."
    },
    {
        "book": "Jonah",
        "chapter": 2,
        "verse": 2,
        "text": "I cried by reason of mine affliction unto the LORD, and he heard me."
    },
    {
        "book": "Micah",
        "chapter": 6,
        "verse": 8,
        "text": "He hath shewed thee, O man, what is good; and what doth the LORD require of thee, but to do justly, and to love mercy, and to walk humbly with thy God?"
    },
    {
        "book": "Nahum",
        "chapter": 1,
        "verse": 7,
        "text": "The LORD is good, a strong hold in the day of trouble; and he knoweth them that trust in him."
    },
    {
        "book": "Habakkuk",
        "chapter": 2,
        "verse": 4,
        "text": "The just shall live by his faith."
    },
    {
        "book": "Zephaniah",
        "chapter": 3,
        "verse": 17,
        "text": "The LORD thy God in the midst of thee is mighty; he will save, he will rejoice over thee with joy."
    },
    {
        "book": "Haggai",
        "chapter": 1,
        "verse": 5,
        "text": "Now therefore thus saith the LORD of hosts; Consider your ways."
    }
    // Add more verses here...
];

// Function to display a random verse
function displayRandomVerse() {
    // Generate a random index
    const randomIndex = Math.floor(Math.random() * verses.length);

    // Get the random verse
    const randomVerse = verses[randomIndex];

    // Display book, chapter, and verse number
    document.getElementById('bookChapter').innerText = `${randomVerse.book} ${randomVerse.chapter}:${randomVerse.verse}`;

    // Display verse text
    document.getElementById('verseText').innerText = randomVerse.text;
}

// Initial display of a random verse
displayRandomVerse();

// Set interval to change verse every 10 minutes (600,000 milliseconds)
setInterval(displayRandomVerse, 28000);

// toggle sibebar shut and open nav
const toggleButton = document.getElementById('toggle-btn');
const sidebar = document.getElementById('sideBar');

function toggleSidebar(){
    sidebar.classList.toggle('close');
    toggleButton.classList.toggle('rotate');
}

