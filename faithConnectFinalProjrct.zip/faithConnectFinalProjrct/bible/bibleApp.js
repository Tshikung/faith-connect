// toggle sibebar shut and open nav
const toggleButton = document.getElementById('toggle-btn');
const sidebar = document.getElementById('sideBar');

function toggleSide_bar(){
    sidebar.classList.toggle('close');
    toggleButton.classList.toggle('rotate');
}


 // Function to toggle the visibility of the chapters
 function toggleChapters(element) {
    // Find the <ul> with class 'chapters' inside the clicked <li>
    const chaptersList = element.querySelector('.chapters');
    if (chaptersList) {
        // Toggle between showing and hiding the list
        if (chaptersList.style.display === "none" || chaptersList.style.display === "") {
            chaptersList.style.display = "flex";
        } else {
            chaptersList.style.display = "none";
        }
    }
}